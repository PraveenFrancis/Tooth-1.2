export class PlanAdd {
    PlanID: number;
    PatientID: number;
    PlanName: string;
    PatientName: string;
}
