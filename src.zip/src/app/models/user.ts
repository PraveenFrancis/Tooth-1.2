export class User {
    UserID: number;
    Name: string;
    Email: string;
    Password: string;
}
