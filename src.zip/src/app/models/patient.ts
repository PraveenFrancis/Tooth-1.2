export class Patient {
    PatientID: number;
    Name: string;
    Email: string;
    Phone: string;
    Gender: string;
    Notes: string;
}
