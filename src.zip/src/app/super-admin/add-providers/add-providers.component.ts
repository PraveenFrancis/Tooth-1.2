import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-providers',
  templateUrl: './add-providers.component.html',
  styleUrls: ['./add-providers.component.css']
})
export class AddProvidersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
