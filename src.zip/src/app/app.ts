export interface IApp {
  id: number;
  name: string;
  age: number;
}
